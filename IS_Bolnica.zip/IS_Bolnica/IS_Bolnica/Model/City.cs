using System;

namespace Model
{
    public class City
    {
        private String name;
        private int postalCode;

        public Country country;

    }
}