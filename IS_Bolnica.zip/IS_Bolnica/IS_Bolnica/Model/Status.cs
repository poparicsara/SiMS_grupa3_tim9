namespace Model
{
    public enum Status
    {
        employed,
        fired,
        quit,
        retired
    }
}