using System;
using System.Collections.Generic;

namespace Model
{
    public class Director : Employee
    {

    }

   
}