namespace Model
{
    public class Patient : User
    {
        public Patient()
        {
            
        }
    }
}