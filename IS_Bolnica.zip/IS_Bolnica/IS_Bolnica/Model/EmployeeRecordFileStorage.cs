using System;
using System.Collections.Generic;

namespace Model
{
    public class EmployeeRecordFileStorage
    {
        public List<Employee> GetAll()
        {
            throw new NotImplementedException();
        }

    }
}