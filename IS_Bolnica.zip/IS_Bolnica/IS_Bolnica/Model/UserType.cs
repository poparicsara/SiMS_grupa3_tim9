﻿namespace Model
{
    public enum UserType
    {
        director,
        patient,
        doctor,
        secretary
    }
}
