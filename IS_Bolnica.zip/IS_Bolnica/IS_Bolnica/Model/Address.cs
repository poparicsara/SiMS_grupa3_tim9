using System;

namespace Model
{
    public class Address
    {
        private String street;
        private String numberOfBuilding;
        private int floor;
        private int apartment;

        public City city;

    }
}