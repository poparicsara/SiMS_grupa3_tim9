using System;

namespace Model
{
    public class GuestUser
    {
        public String SystemName { get; set; }
        public String InjuryDescription { get; set; }

    }
}