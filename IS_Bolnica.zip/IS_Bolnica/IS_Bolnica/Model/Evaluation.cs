namespace Model
{
    public enum Evaluation
    {
        poor,
        fair,
        good,
        veryGood,
        excellent
    }
}