namespace Model
{
    public class Doctor : Employee
    {
        public Specialization specialization;

    }
}