using System;

namespace Model
{
    public class Specialization
    {
        public String name;

    }
}