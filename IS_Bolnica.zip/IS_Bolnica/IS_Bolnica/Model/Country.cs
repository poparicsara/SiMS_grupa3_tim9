using System;

namespace Model
{
    public class Country
    {
        private String name;

    }
}