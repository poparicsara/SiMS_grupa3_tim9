using System;

namespace Model
{
    public class Secretary : Employee
    {
        public void AddUser(String username, String password, String name, String surname, DateTime dateOfBirth, int phone, int id, String email)
        {
            throw new NotImplementedException();
        }

        public void DeleteUser(int id)
        {
            throw new NotImplementedException();
        }

        public int CreateGuestUser(String systemName, String injuryDescription)
        {
            throw new NotImplementedException();
        }

    }
}