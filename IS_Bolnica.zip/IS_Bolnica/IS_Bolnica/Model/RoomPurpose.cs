using System;

namespace Model
{
    public class RoomPurpose
    {
        public String Name { get; set; }
    }
}