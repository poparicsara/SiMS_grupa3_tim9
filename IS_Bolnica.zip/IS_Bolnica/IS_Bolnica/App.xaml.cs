﻿using System.Windows;

namespace IS_Bolnica
{

    public partial class App : Application
    {
    }
}
